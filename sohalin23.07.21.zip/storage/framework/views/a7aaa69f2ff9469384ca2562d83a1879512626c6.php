<?php $__env->startSection('content'); ?>


    <div class="calendarMain">
        <h2>Календарь событий</h2>
        <div class="calendarMap">
            <a href="#" class="calendarMapEv">Ближайшие</a>
        </div>
        <div class="calendarItem col-xs-12 col-md-3">
            <div class="calendarImg">
                <a href="/event/1"><img src="/images/ivent1.jpeg" class="img-responsive"></a>
            </div>
            <div class="calendarTitle"><a href="/event/1">ДЕНЬ МОЛОДЁЖИ РОССИИ</a></div>
            <div class="calenderDate">
                26.06.2021
            </div>
        </div>
               <div class="calendarItem col-xs-12 col-md-3">
            <div class="calendarImg">
                <a href="/event/1"><img src="/images/ivent1.jpeg" class="img-responsive"></a>
            </div>
            <div class="calendarTitle"><a href="/event/1">ДЕНЬ МОЛОДЁЖИ РОССИИ</a></div>
            <div class="calenderDate">
                26.06.2021
            </div>
        </div>
               <div class="calendarItem col-xs-12 col-md-3">
            <div class="calendarImg">
                <a href="/event/1"><img src="/images/ivent1.jpeg" class="img-responsive"></a>
            </div>
            <div class="calendarTitle"><a href="/event/1">ДЕНЬ МОЛОДЁЖИ РОССИИ</a></div>
            <div class="calenderDate">
                26.06.2021
            </div>
        </div>
               <div class="calendarItem col-xs-12 col-md-3">
            <div class="calendarImg">
                <a href="/event/1"><img src="/images/ivent1.jpeg" class="img-responsive"></a>
            </div>
            <div class="calendarTitle"><a href="/event/1">ДЕНЬ МОЛОДЁЖИ РОССИИ</a></div>
            <div class="calenderDate">
                26.06.2021
            </div>
        </div>
    </div>
    <div class="textInMain">
        <h2>О проекте</h2>
        <p>SakhaLink - это молодёжная платформа Сахалинской области для общения активных, неравнодушных, жаждущих развития и самореализации.</p>
<h3>Здесь ты найдёшь:</h3>
<ul>
<li>афишу мероприятий, проходящих на территории Сахалинской области, в интерактивной таблице на сайте;</li>
<li>обзоры крутых и современных проектов на островах в нашей группе в ВКонтакте;</li>
<li>истории успеха сахалинских инфлюенсеров в Instagram;</li>
<li>экспертный взгляд на социальные медиа в Telegram;</li>
<li>образовательные онлайн семинары и лекции;</li>
<li>новые знакомства и совместные коллаборации.</li>
</ul>
<p>Ты готов изменить свой взгляд на будущее? <br />Хочешь вести свой блог, развивать личный бренд или найти команду? Тебе важно быть в курсе новых трендов? Ты не боишься пробовать и рисковать?</p>
<p>Тогда SakhaLink для тебя и про тебя!<br />Присоединяйся, общайся, делись новым!</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a/artimnie/artimnie.beget.tech/public_html/resources/views/main.blade.php ENDPATH**/ ?>