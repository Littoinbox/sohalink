<div class="navbar navbar-default" role="navigation">
    <div class="navbar-header">
        <a class="logoInMenu" href="/"><img src="/images/min-logo.png"></a>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>

    </div>
    <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="/">О проекте</a></li>
            <li><a href="#">Новости</a></li>
            <li><a href="#">Афиша</a></li>
            <li><a href="#">Города</a></li>
            <li><a href="#">Проекты</a></li>
            <li><a href="#">Контакты</a></li>
        </ul>
    </div>
</div>
<?php /**PATH /home/a/artimnie/sakhalink.online/public_html/resources/views/inc/nav.blade.php ENDPATH**/ ?>