<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title); ?></title>

    <!-- Scripts -->
    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.js"></script>
    <script src="/js/app.js"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet">
</head>
<body>
<div class="container-fluid" id="main">
    <div class="container">
        <?php echo $__env->make("inc.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="container">
        <?php echo $__env->make("inc.slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="container">
        
        
        <?php echo $__env->yieldContent('content'); ?>

    </div>


</div>

<div class="footer container-fluid">
    <div class="container">
        <div class="col-xs-12 col-md-6">
            <ul class="footer-menu">
                <li class="active"><a href="#">О проекте</a></li>
                <li><a href="#">Новости</a></li>
                <li><a href="#">Афиша</a></li>
                <li><a href="#">Города</a></li>
                <li><a href="#">Проекты</a></li>
                <li><a href="#">Контакты</a></li>
            </ul>
        </div>
        <div class="col-xs-12 col-md-6 social">
            <h3>Мы в социальных сетях</h3>
            <a href="https://t.me/SakhaLink" target="_blank"><img src="/images/telega.jpg" class="" /></a>
            <a href="https://instagram.com/sakhalink.online"  target="_blank"><img src="/images/in.png" class="" /></a>
            <a href="https://vk.com/publicsakhalink"  target="_blank"><img src="/images/vk.png" class="" /></a>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH /home/a/artimnie/artimnie.beget.tech/public_html/resources/views/layouts/main.blade.php ENDPATH**/ ?>